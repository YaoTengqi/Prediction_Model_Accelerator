#include "../src/layernorm.hpp"
#include "../include/binFiles.hpp"
#include "../include/utils.hpp"

int main() {
    string basedir = "/media/sy/data/project/Large_Project_Phase_2/layer_norm/layernorm-pytorch/data";

    vector<t_AXI_DataType> input_data, para_data, golden;
    vector<t_AXI_DataType> output_data(ROWS * COLS * sizeof(t_DataType_B) / sizeof(t_AXI_DataType), 0);
    ap_uint<32> input_data_addr = 0;
    ap_uint<32> para_addr = OWS * COLS * sizeof(t_DataType_A);
    ap_uint<32> input_data_addr = 0;

    readBin(basedir + "dram.bin", sizeof(t_DataType_A) * ROWS * COLS, input_data);
    readBin(basedir + "output_data.bin", sizeof(t_DataType_B) * ROWS * COLS, golden);
    // readBin(basedir + "para_data.bin", sizeof(t_ParaType) * COLS * 2, para_data);
    layernorm(
        input_data_addr, 
        para_addr, 
        output_data_addr, 
        input_data.data(), 
        output_data.data(), 
        para_data.data());

    int err = 0;
    bool l_compare = compare(ROWS * COLS * sizeof(t_DataType_B) / sizeof(t_AXI_DataType), golden.data(), output_data.data(), err);

    if (l_compare) {
        cout << "Pass!\n";
        return 0;
    } else {
        cout << "Fail with " << err << " errors!\n";
        return -1;
    }

}
