#include "types.hpp"
#include "hls_stream.h"
#include "ap_int.h"


namespace xf {
//
namespace blas {
//
namespace {

template <  typename t_DataType_A, 
            typename t_AXI_DataType, 
            unsigned int t_nPE, 
            unsigned int t_m, 
            unsigned int t_n>
void DataMover_A(unsigned int addr,
                t_AXI_DataType *inputs,
                hls::stream<typename WideType<t_DataType_A, t_nPE>::t_TypeInt>& stream_a,
                hls::stream<typename WideType<t_DataType_A, t_nPE>::t_TypeInt>& stream_b,
                hls::stream<typename WideType<t_DataType_A, t_nPE>::t_TypeInt>& stream_c
          ) {
//#pragma HLS array_reshape variable=ram type=complete dim=1
    unsigned int ram_depth = t_m * t_n / t_nPE;
    typename WideType<t_DataType_A, t_nPE>::t_TypeInt ram[ram_depth];
    memcpy(&ram[0], (const t_AXI_DataType *)&inputs[addr], t_m * t_n * sizeof(t_DataType_A));

    uint8_t stream_a_addr = 0 ,stream_b_addr = 0 ,stream_c_addr = 0;
    while(stream_c_addr != (ram_depth)){
        if(!stream_a.full()){
            stream_a.write(ram[stream_a_addr]);
            stream_a_addr ++;
        }

        if(!stream_b.full()){
            stream_b.write(ram[stream_b_addr]);
            stream_b_addr ++;
        }

        if(!stream_c.full()){
            stream_c.write(ram[stream_c_addr]);
            stream_c_addr ++;
        }                
    }  
}

template <typename t_DataType_A, typename t_AXI_DataType, unsigned int t_nPE, unsigned int t_m , unsigned int t_n>
void DataMover_B(unsigned int addr, 
                t_AXI_DataType *inputs,
                hls::stream<typename WideType<t_DataType_A, t_nPE>::t_TypeInt>& stream_a,
                hls::stream<typename WideType<t_DataType_A, t_nPE>::t_TypeInt>& stream_b
          ) {
    unsigned int ram_depth = t_n/t_nPE;
    typename WideType<t_DataType_A, t_nPE>::t_TypeInt gamma_ram[ram_depth];
    typename WideType<t_DataType_A, t_nPE>::t_TypeInt beta_ram[ram_depth];

    unsigned int offset = t_n * sizeof(t_DataType_A)/sizeof(t_AXI_DataType);
#pragma HLS BIND_OP variable=offset op=mul impl=fabric latency=3 
    unsigned int beta_addr = addr + offset;
#pragma HLS BIND_OP variable=beta_addr op=add impl=fabric latency=2 
    memcpy(&gamma_ram[0], (const t_AXI_DataType *)&inputs[addr], t_n * sizeof(t_DataType_A));   
    memcpy(&beta_ram[0], (const t_AXI_DataType *)&inputs[beta_addr], t_n * sizeof(t_DataType_A));

    for (int i = 0; i < t_m; i++) {
        for (int j = 0; j < (t_n/t_nPE); j++) {
#pragma HLS UNROLL 
                stream_a.write(gamma_ram[j]);
                stream_b.write(beta_ram[j]);
        }             
    }  
}

template <typename t_DataType_A, unsigned int t_nPE, unsigned int t_m , unsigned int t_n>
void Mean(hls::stream<typename WideType<t_DataType_A, t_nPE>::t_TypeInt>& p_x,
          hls::stream<typename WideType<t_DataType_A, 1>::t_TypeInt>& mean_a,
          hls::stream<typename WideType<t_DataType_A, 1>::t_TypeInt>& mean_b
          ) {
    WideType<t_DataType_A, t_nPE> valX;
    WideType<t_DataType_A, 1> mean;

    for (int k = 0; k < t_m; k++) {
        int sum = 0;
        Sum:
        for (int j = 0; j < t_n/t_nPE; j++) {
#pragma HLS PIPELINE
            valX = p_x.read();
            for (int i = 0; i < t_nPE; i++) {
                sum += valX[i];
            }
        }
        mean[0] = sum / t_n;
        mean_a.write(mean[0]);
        mean_b.write(mean[0]);
    }
}

template <typename t_DataType_A, typename t_DataType_B, typename t_DataType_C, typename t_DataType_D, unsigned int t_nPE, unsigned int t_m , unsigned int t_n>
void StdDev(hls::stream<typename WideType<t_DataType_A, t_nPE>::t_TypeInt>& p_x,
            hls::stream<typename WideType<t_DataType_A, 1>::t_TypeInt>& mean,
            hls::stream<typename WideType<t_DataType_B, 1>::t_TypeInt>& stddev
            ) {
    WideType<t_DataType_A, t_nPE> valX;
    WideType<t_DataType_A, 1> mean_val;
    WideType<t_DataType_B, 1> stddev_val;
    
    for (int k = 0; k < t_m; k++) {
        t_DataType_D diff_sum = 0;
        mean_val[0] = mean.read();
        StdDev:
        for (int j = 0; j < t_n/t_nPE; j++) {
#pragma HLS PIPELINE
            valX = p_x.read();
            for (int i = 0; i < t_nPE; i++) {
                t_DataType_C diff = valX[i] - mean_val[0];
                diff_sum = hls::fma(diff, diff, diff_sum);
            }
        }
        stddev_val[0] = hls::sqrt(t_DataType_B(diff_sum / t_n));
        stddev.write(stddev_val);
    }
}

template <typename t_DataType_A, typename t_DataType_B, unsigned int t_nPE, unsigned int t_m , unsigned int t_n>
void Norm(hls::stream<typename WideType<t_DataType_A, t_nPE>::t_TypeInt>& p_x,
          hls::stream<typename WideType<t_DataType_A, 1>::t_TypeInt>& mean,
          hls::stream<typename WideType<t_DataType_B, 1>::t_TypeInt>& stddev,
          hls::stream<typename WideType<t_DataType_B, t_nPE>::t_TypeInt>& gamma,
          hls::stream<typename WideType<t_DataType_B, t_nPE>::t_TypeInt>& beta,
          hls::stream<typename WideType<t_DataType_B, t_nPE>::t_TypeInt>& norm
          ) {
    WideType<t_DataType_A, t_nPE> valX;
    WideType<t_DataType_B, t_nPE> norm_val;
    WideType<t_DataType_B, t_nPE> norm_val_temp;
    WideType<t_DataType_B, t_nPE> gamma_val;
    WideType<t_DataType_B, t_nPE> beta_val;
    WideType<t_DataType_A, 1> mean_val;
    WideType<t_DataType_B, 1> stddev_val;

    for (int k = 0; k < t_m; k++) {
        mean_val = mean.read();
        stddev_val = stddev.read();
        norm:
        for (int j = 0; j < t_n/t_nPE; j++) {
#pragma HLS PIPELINE
            valX = p_x.read();
            gamma_val = gamma.read();
            beta_val = beta.read();
            for (int i = 0; i < t_nPE; i++) {
                norm_val_temp[i] = (valX[i] - mean_val[0]) / stddev_val[0];
                norm_val[i] = norm_val_temp[i] * gamma_val[i] + beta_val[i];
// #pragma HLS BIND_OP variable=norm_val op=fmadd impl=meddsp latency=4
            }
            norm.write(norm_val);
        }
    }
    
}

template <typename t_DataType_A, typename t_DataType_B, unsigned int t_nPE, unsigned int t_m , unsigned int t_n>
void Relu(hls::stream<typename WideType<t_DataType_A, t_nPE>::t_TypeInt>& p_x,
            hls::stream<typename WideType<t_DataType_B, t_nPE>::t_TypeInt>& p_y
          ) {
    WideType<t_DataType_A, t_nPE> l_x;
    WideType<t_DataType_B, t_nPE> l_y;
    for (int j = 0; j < t_m * t_n/t_nPE; j++) {
#pragma HLS PIPELINE
        l_x = p_x.read();
        for (int i = 0; i < t_nPE; i++) {      
            l_y[i] = t_DataType_B(l_x[i] * 100);
        }
        p_y.write(l_y);
    }
}

template <typename t_DataType_A, typename t_AXI_DataType, unsigned int t_nPE, unsigned int t_m , unsigned int t_n>
void Store(unsigned int addr, 
            t_AXI_DataType *outputs,
            hls::stream<typename WideType<t_DataType_A, t_nPE>::t_TypeInt>& p_x
          ) {
    unsigned int dst_idx = addr;
    unsigned int loop_idx = t_nPE * sizeof(t_DataType_A) / sizeof(t_AXI_DataType);
    unsigned int loop_num = t_m * t_n / t_nPE;
    for (int i = 0; i < loop_num; i++) {    
#pragma HLS PIPELINE           
        WideType<t_DataType_A, t_nPE> l_x = p_x.read();
        memcpy(const_cast<t_AXI_DataType *> (&outputs[dst_idx]), &l_x[0], t_nPE * sizeof(t_DataType_A));
        dst_idx = dst_idx + loop_idx;
#pragma HLS BIND_OP variable=dst_idx op=add impl=fabric latency=2
    }
}

}
} // end namespace blas

} // end namespace xf
