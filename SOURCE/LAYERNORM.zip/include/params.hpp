/*
 * Copyright 2019 Xilinx, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
*/
#pragma once
#include <cmath> 

#define COLS_LOG 6
#define ROWS 40
#define COLS (1 << COLS_LOG)
#define nPE 32
#define AXI_DATA_WIDTH 256
#define INP_DATA_WIDTH 8
#define OUT_DATA_WIDTH 8
#define STD_DIFF_WIDTH (INP_DATA_WIDTH + 1)
#define STD_SUM_WIDTH (STD_DIFF_WIDTH + STD_DIFF_WIDTH + COLS_LOG)

#define t_ParaType float
#define t_DataType_A ap_int<INP_DATA_WIDTH>
#define t_DataType_B ap_int<OUT_DATA_WIDTH>
#define t_DataType_C ap_int<STD_DIFF_WIDTH>
#define t_DataType_D ap_int<STD_SUM_WIDTH>
#define t_AXI_DataType ap_uint<AXI_DATA_WIDTH>


