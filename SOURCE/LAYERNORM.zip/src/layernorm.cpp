#include "layernorm.hpp"

void layernorm(
    uint32_t input_data_addr, 
    uint32_t para_addr, 
    uint32_t output_data_addr, 
	t_AXI_DataType *inputs,
	t_AXI_DataType *outputs,
	t_AXI_DataType *paras)
    {

#pragma HLS INTERFACE mode = m_axi port = inputs bundle = ln_data
#pragma HLS INTERFACE mode = m_axi port = paras bundle = ln_paras
#pragma HLS INTERFACE mode = m_axi port = outputs bundle = ln_data
#pragma HLS INTERFACE s_axilite port = input_data_addr bundle = ln_addr
#pragma HLS INTERFACE s_axilite port = para_addr bundle = ln_addr
#pragma HLS INTERFACE s_axilite port = output_data_addr bundle = ln_addr
#pragma HLS INTERFACE s_axilite port = return bundle = ln_addr

    hls::stream<typename WideType<t_DataType_A, nPE>::t_TypeInt> data_copy_a;
#pragma HLS STREAM variable=data_copy_a depth=8
    hls::stream<typename WideType<t_DataType_A, nPE>::t_TypeInt> data_copy_b;
#pragma HLS STREAM variable=data_copy_b depth=8
    hls::stream<typename WideType<t_DataType_A, nPE>::t_TypeInt> data_copy_c;
#pragma HLS STREAM variable=data_copy_c depth=8
    hls::stream<typename WideType<t_ParaType, nPE>::t_TypeInt> gamma;
#pragma HLS STREAM variable=gamma depth=4
    hls::stream<typename WideType<t_ParaType, nPE>::t_TypeInt> beta;
#pragma HLS STREAM variable=beta depth=4
    hls::stream<typename WideType<t_DataType_A, 1>::t_TypeInt> mean_a;
#pragma HLS STREAM variable=mean_a depth=40
    hls::stream<typename WideType<t_DataType_A, 1>::t_TypeInt> mean_b;
#pragma HLS STREAM variable=mean_b depth=40
    hls::stream<typename WideType<t_ParaType, 1>::t_TypeInt> stddev;
#pragma HLS STREAM variable=stddev depth=40
    hls::stream<typename WideType<t_ParaType, nPE>::t_TypeInt> norm;
#pragma HLS STREAM variable=norm depth=4
    hls::stream<typename WideType<t_DataType_B, nPE>::t_TypeInt> relu;
#pragma HLS STREAM variable=relu depth=4

#pragma HLS DATAFLOW
    DataMover_A<t_DataType_A, t_AXI_DataType, nPE, ROWS, COLS>(input_data_addr, inputs, data_copy_a, data_copy_b, data_copy_c);
    DataMover_B<t_ParaType, t_AXI_DataType, nPE, ROWS, COLS>(para_addr, paras, gamma, beta);
    Mean<t_DataType_A, nPE, ROWS, COLS>(data_copy_a, mean_a, mean_b);
    StdDev<t_DataType_A, t_ParaType, nPE, ROWS, COLS>(data_copy_b, mean_a, stddev);
    Norm<t_DataType_A, t_ParaType, t_DataType_C, t_DataType_D, nPE, ROWS, COLS>(data_copy_c, mean_b, stddev, gamma, beta ,norm);
    Relu<t_ParaType, t_DataType_B, nPE, ROWS, COLS>(norm, relu);
    Store<t_DataType_B, t_AXI_DataType, nPE, ROWS, COLS>(output_data_addr, outputs, relu);
}
